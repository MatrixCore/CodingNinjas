param($installPath, $toolsPath, $package, $project)

$project.DTE.ItemOperations.Navigate('https://github.com/xceedsoftware/wpftoolkit')