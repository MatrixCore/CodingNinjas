﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
     /* 
     03/04-10-17
     Kelly added mean test calculations, I changed the read only condition of boxes such as PayeDeduction and rebate boxes since I understand we need to
     input those values?. Added a button on the assets calculation tab but I can join both calculations under one buttom.          
    */
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void EvaluateMeans_Click(object sender, RoutedEventArgs e)
        {
            /* 
            Based on the figures entered, it can be determined whether or not the client in question qualifies for aid
            One of three outcomes then may be dediced upon by the client
            1. Client Qualifies and books appointment
            2. Client doesn’t qualify but requires advice
            3. Client doesn't qualify but doesn’t want advice
            */

            Double Ssalary = Convert.ToDouble(textBox.Text);
            Double Sallowance = Convert.ToDouble(textBox5.Text);
            Double Ssubsidy = Convert.ToDouble(textBox1.Text);
            Double Sinterest = Convert.ToDouble(textBox3.Text);
            Double Srental = Convert.ToDouble(textBox2.Text);
            Double Smaintenance = Convert.ToDouble(textBox6.Text);
            Double Sincome = Convert.ToDouble(textBox4.Text);
          
            Double Sgrossincome = Ssalary + Sallowance + Ssubsidy + Sinterest + Srental + Smaintenance + Sincome;

            Double Psalary = Convert.ToDouble(textBox8.Text);
            Double Pallowance = Convert.ToDouble(textBox9.Text);
            Double Psubsidy = Convert.ToDouble(textBox10.Text);
            Double Pinterest = Convert.ToDouble(textBox11.Text);
            Double Prental = Convert.ToDouble(textBox12.Text);
            Double Pmaintenance = Convert.ToDouble(textBox13.Text);
            Double Pincome = Convert.ToDouble(textBox14.Text);
 
            Double Pgrossincome = Psalary + Pallowance + Psubsidy + Pinterest + Prental + Pmaintenance + Pincome;

            Double Totgrossincome = Sgrossincome + Pgrossincome;

            Double Sdeduction = Convert.ToDouble(textBox17.Text);
            Double Pdeduction = Convert.ToDouble(textBox18.Text);

            Double Totdeduction = Sdeduction + Pdeduction;

            Double Total = Totgrossincome - Totdeduction;
            Double Rebate = Convert.ToDouble(textBox19_Copy1.Text);
            Double Balance = Total - Rebate;

            textBox7.Text = Convert.ToString(Sgrossincome);
            textBox15.Text = Convert.ToString(Pgrossincome);
            textBox17.Text = Convert.ToString(Sdeduction);
            textBox18.Text = Convert.ToString(Pdeduction);
            textBox16.Text = Convert.ToString(Totgrossincome);
            textBox19.Text = Convert.ToString(Totdeduction);
            textBox19_Copy.Text = Convert.ToString(Total);
            textBox19_Copy2.Text = Convert.ToString(Balance);

        }



        private void Appointment_Click(object sender, RoutedEventArgs e)
        {
            /*
            We will need to design a way to manage and add appointments
            This button should only be enabled if the means test as already been completed
            */
        }

        private void Meeting_Click(object sender, RoutedEventArgs e)
        {
            /*
            Same as the Appointment Button
            What's the difference between a meeting and an appointment
            */
        }

        private void EvaluateAssets_Click(object sender, RoutedEventArgs e)
        {
            Double Sfixproperty = Convert.ToDouble(textBox20.Text);
            Double Sbonds = Convert.ToDouble(textBox20_Copy.Text);
            Double Ssavings = Convert.ToDouble(textBox20_Copy2.Text);
            Double Smonies = Convert.ToDouble(textBox20_Copy3.Text);

            Double Ssubtotal = Sfixproperty - Sbonds ;
            Double Snetvalue = Ssubtotal+ Ssavings + Smonies;

            Double Pfixproperty = Convert.ToDouble(textBox20_Copy8.Text);
            Double Pbonds = Convert.ToDouble(textBox20_Copy7.Text);
            Double Psavings = Convert.ToDouble(textBox20_Copy5.Text);
            Double Pmonies = Convert.ToDouble(textBox20_Copy4.Text);

            Double Psubtotal = Pfixproperty - Pbonds;
            Double Pnetvalue = Psubtotal + Psavings + Pmonies;

            Double Totnetvalue = Snetvalue + Pnetvalue;
      
            if (Sfixproperty >0 || Pfixproperty >0)
            {
                textBox23.Text = Convert.ToString(500000);
            }

            Double Propdiscount = Convert.ToDouble(textBox23.Text);

            Double Balanceassets = Totnetvalue - Propdiscount;


            textBox20_Copy1.Text = Convert.ToString(Ssubtotal);
            textBox20_Copy6.Text = Convert.ToString(Psubtotal);
            textBox21.Text = Convert.ToString(Snetvalue);
            textBox21_Copy.Text = Convert.ToString(Pnetvalue);
            textBox22.Text = Convert.ToString(Totnetvalue);
            textBox24.Text = Convert.ToString(Balanceassets);
        }
    }

}